package com.aws.ebs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EbsDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
