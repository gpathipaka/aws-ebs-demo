package com.aws.ebs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EbsDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EbsDemoApplication.class, args);
	}

}
